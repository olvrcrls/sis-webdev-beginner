<?php

	define('db_server','localhost');
	define('db_user','u106676521_root');
	define('db_password','jxLBAMBgs8Xv59V8NF');
	define('db_database','u106676521_sjnhs');

?>