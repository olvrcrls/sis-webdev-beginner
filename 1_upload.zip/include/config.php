<?php

	define('db_server','localhost');
	define('db_user','u461501393_root');
	define('db_password','XLfm4YaZR:3JhER82p');
	define('db_database','u461501393_sjnhs');

?>