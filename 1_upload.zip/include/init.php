<?php

	session_start();
	$_SESSION['log'] = false;
	$_SESSION['id'] = '';
	$_SESSION['username'] = '';
	$_SESSION['type'] = '';

?>